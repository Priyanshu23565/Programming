from flask import Flask, render_template,send_from_directory

app = Flask(__name__)

@app.route('/')
def data():
    return render_template('index.html')

@app.route('/music')
def data1():
    return render_template('music.html')


@app.route('/musicd')
def data12():
    return send_from_directory('templates','music_data.json',mimetype='application/json')

if __name__ == '__main__':
    app.run(debug=True)
